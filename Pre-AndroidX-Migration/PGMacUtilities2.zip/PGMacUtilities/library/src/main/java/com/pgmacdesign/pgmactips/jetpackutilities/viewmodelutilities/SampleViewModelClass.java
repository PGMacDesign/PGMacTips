package com.pgmacdesign.pgmactips.jetpackutilities.viewmodelutilities;

import java.util.Random;

import androidx.lifecycle.ViewModel;

public class SampleViewModelClass extends ViewModel {

    //Vars
    private int randomNum;

    /**
     * Setup a random number between 1000 -- 9999
     */
    private void createNumber() {
        this.randomNum = new Random().nextInt(8999) + 1000;
    }

    public int getNumber(){
        if(this.randomNum <= 0){
            this.createNumber();
        }
        return this.randomNum;
    }
}
