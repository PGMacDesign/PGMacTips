package com.pgmacdesign.pgmactips.enhancedphotoclasses;

/**
 * Created by PatrickSSD2 on 9/21/2016.
 */
@Deprecated
interface CustomPhotoListener {
    //todo Will add more here
    public void facesChanged(int numberOfFaces );
    public void countdownFinished(boolean bool);
}
