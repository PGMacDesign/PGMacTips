package com.pgmacdesign.pgmactips.datamodels;

public enum ImageMimeType {
    JPEG, PNG, GIF, UNKNOWN
}
