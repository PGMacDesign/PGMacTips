package com.pgmacdesign.pgmactips.utilities;

/**
 * Created by pmacdowell on 2017-08-25.
 */

public class BoolUtilities {

    public static boolean isTrue(Boolean bool){
        if(bool == null){
            return false;
        } else {
            return bool;
        }
    }


}
