package com.pgmacdesign.pgmactips.jetpackutilities.viewmodelutilities;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.widget.TextView;

import com.pgmacdesign.pgmactips.R;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProviders;

public class SampleViewModelUsage extends AppCompatActivity {

    /*
    Info:
        View Model Structure:
            1) Activity is created and the view model remains active until it is destroyed.
            2) Once destroyed, onClear() is called within the ViewModel class to clear up things
                a) This is the best spot to clear up memory saved within the ViewModel
            3) Note that ViewModel is NOT the same as onSaveInstanceState()

     */


    //UI
    private TextView view_model_tv;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        this.setContentView(R.layout.sample_view_model_usage);
        this.view_model_tv = (TextView) this.findViewById(R.id.view_model_tv);
        //Instance of the ViewModel class
        SampleViewModelClass viewModel = ViewModelProviders.of(this).get(SampleViewModelClass.class);

        int x = viewModel.getNumber();
        this.view_model_tv.setText(x + "");
    }

}
