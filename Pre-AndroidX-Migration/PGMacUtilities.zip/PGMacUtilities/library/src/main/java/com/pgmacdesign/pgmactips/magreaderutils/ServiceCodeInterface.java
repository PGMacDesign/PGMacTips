
package com.pgmacdesign.pgmactips.magreaderutils;


/**
 * Interface for use in the {@link MagneticTrackMagReader} class
 */
interface ServiceCodeInterface {
    public String getText();
    public int getCode();

}
